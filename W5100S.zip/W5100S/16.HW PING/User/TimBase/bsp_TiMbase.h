/**
******************************************************************************
* @file         bsp_TiMbase.h                                                                                              
* @version      V1.0                          
* @date         2018-06-18                       
* @brief        bsp_TiMbase.c��ͷ�ļ�
*        
* @company      ��������Ƽ����޹�˾
* @information  WIZnet W5100s�ٷ������̣�ȫ�̼���֧�֣��۸����ƴ�
* @website      www.wisioe.com
* @forum        www.w5100s.com
* @qqGroup      579842114                                                     
******************************************************************************
*/
#ifndef TIME_TEST_H
#define TIME_TEST_H

#include "stm32f10x.h"

void TIM2_NVIC_Configuration(void);
void TIM2_Configuration(void);

#endif  /* TIME_TEST_H */
