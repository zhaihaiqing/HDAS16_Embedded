/**
******************************************************************************
* @file         bsp_fsmc.h                                                                                              
* @version      V1.0                          
* @date         2018-06-18                       
* @brief        bsp_fsmc.c��ͷ�ļ�
*        
* @company      ��������Ƽ����޹�˾
* @information  WIZnet W5100s�ٷ������̣�ȫ�̼���֧�֣��۸����ƴ�
* @website      www.wisioe.com  
* @forum        www.w5100s.com
* @qqGroup      579842114                                                     
******************************************************************************
*/
#ifndef _BSP_FSMC_H_
#define _BSP_FSMC_H_

#define STM32F103VET6

//#define STM32F103ZET6

void FSMC_gpio_init(void);
void FSMCInitialize(void);

#endif //_BSP_FSMC_H
